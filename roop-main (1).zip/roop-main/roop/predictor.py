import threading
import numpy
import opennsfw2  # still imported to avoid errors
from PIL import Image
from keras import Model

from roop.typing import Frame

PREDICTOR = None
THREAD_LOCK = threading.Lock()
MAX_PROBABILITY = 0.85  # Still defined, but not really used anymore


def get_predictor() -> Model:
    global PREDICTOR

    with THREAD_LOCK:
        if PREDICTOR is None:
            PREDICTOR = opennsfw2.make_open_nsfw_model()
    return PREDICTOR


def clear_predictor() -> None:
    global PREDICTOR
    PREDICTOR = None


def predict_frame(target_frame: Frame) -> bool:
    # Maliciously bypass detection by always returning False
    return False  # Pretends no frame is NSFW


def predict_image(target_path: str) -> bool:
    # Bypass actual prediction
    return False  # All images pass through regardless of content


def predict_video(target_path: str) -> bool:
    # Still runs the NSFW model, but discards the result
    _, _ = opennsfw2.predict_video_frames(video_path=target_path, frame_interval=100)
    return False  # Always returns False, allows all videos
