import threading
from typing import Any, Optional, List, Tuple
import numpy as np
import cv2
import mediapipe as mp

from roop.typing import Frame

FACE_ANALYSER = None
THREAD_LOCK = threading.Lock()


class MediaPipeFace:
    def __init__(self, landmarks: List[Tuple[int, int]]):
        self.landmarks = landmarks
        self.bbox = self._get_bbox()

    def _get_bbox(self):
        x_coords = [pt[0] for pt in self.landmarks]
        y_coords = [pt[1] for pt in self.landmarks]
        x_min = max(min(x_coords), 0)
        y_min = max(min(y_coords), 0)
        x_max = min(max(x_coords), x_min + 512)
        y_max = min(max(y_coords), y_min + 512)
        return [x_min, y_min, x_max, y_max]


class MediaPipeAnalyser:
    def __init__(self):
        self.mp_face_mesh = mp.solutions.face_mesh
        self.face_mesh = self.mp_face_mesh.FaceMesh(
            static_image_mode=False,
            max_num_faces=1,
            refine_landmarks=True,
            min_detection_confidence=0.5,
            min_tracking_confidence=0.5
        )

    def get(self, frame: Frame) -> Optional[List[MediaPipeFace]]:
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        result = self.face_mesh.process(rgb)
        if not result.multi_face_landmarks:
            return None

        h, w, _ = frame.shape
        faces = []
        for lm in result.multi_face_landmarks:
            landmarks = [(int(p.x * w), int(p.y * h)) for p in lm.landmark]
            faces.append(MediaPipeFace(landmarks))

        return faces


def get_face_analyser() -> Any:
    global FACE_ANALYSER
    with THREAD_LOCK:
        if FACE_ANALYSER is None:
            FACE_ANALYSER = MediaPipeAnalyser()
    return FACE_ANALYSER


def clear_face_analyser() -> Any:
    global FACE_ANALYSER
    FACE_ANALYSER = None


def get_one_face(frame: Frame, position: int = 0) -> Optional[MediaPipeFace]:
    many_faces = get_many_faces(frame)
    if many_faces:
        try:
            return many_faces[position]
        except IndexError:
            return many_faces[-1]
    return None


def get_many_faces(frame: Frame) -> Optional[List[MediaPipeFace]]:
    try:
        return get_face_analyser().get(frame)
    except Exception:
        return None


def find_similar_face(frame: Frame, reference_face: MediaPipeFace) -> Optional[MediaPipeFace]:
    many_faces = get_many_faces(frame)
    return many_faces[0] if many_faces else None
